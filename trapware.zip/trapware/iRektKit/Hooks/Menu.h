#pragma once


//now it should encrypt cuz im too cool 4 u all

//const char* M4A1Ss = charenc("Masterpiece\0\rHyper Beast\0\rCyrex\0\rHot Rod\0\rGuardian\0\rIcarus Fell\0\rBasilisk\0\rGolden Coil\0\rAtomic Alloy\0\rNitro\0\rKnight\0\rChantico's Fire\0\0");

const char* M4A1s[] =
{
"Royal Paladin",
"Howl",
"Poseidon",
"Dragon King",
"Asiimov",
"Desolate Space",
};
//Bloodhound\0Sport\0Driver\0Wraps\0Moto\0Specialist\0\0

const char* AWPs[] =
{
"Hyper Beast",
"Asiimov",
"Dragon Lore",
"Lightning Strike",
"Redline",
"Pit Viper",
"Graphite",
"BOOM",
"Pink DDPAT",
"Man-o'-War",
"Corticera",
"Electric Hive",
"Medusa",
"Sun in Leo",
"Elite Build",
"Phobos",
"Safari Mesh",
};

const char* GLOCKs[] =
{
"Water Elemental",
"Fade",
"Twilight Galaxy",
"Bunsen Burner",
"Candy Apple",
"Wasteland Rebel",
"Royal Legion",
"Weasel"
};

const char* Berettass[] =
{
	"Hemoglobin",
	"Urban Shock",
	"Royal Consorts",
	"Marina",
	"Demolition"
};

const char* USPSs[] =
{
"Kill Confirmed",
"Road Rash",
"Stainless",
"Guardian"
};

const char* DEAGLEs[] =
{
"Crimson Web",
"Blaze",
"Conspiracy",
"Cobalt Disruption",
"Urban DDPAT",
"Hypnotic"
};

const char* KnifeSkin[] =
{
	"hz cho za skin",
	"Blaze",
	"Conspiracy",
	"Cobalt Disruption",
	"Urban DDPAT",
	"Hypnotic"
};

const char* AK47s[] =
{
"Jet Set",
"Cartel",
"Aquamarine Revenge",
"Vulcan",
"Fire Serpent",
"Jaguar",
"Hydroponic",
"Case Hardened",
"Wasterland Rebel",
"Redline",
};

//const char* aimBones = XorStr("PELVIS\0\r\0\r\0\rHIP\0\rLOWER SPINE\0\rMIDDLE SPINE\0\rUPPER SPINE\0\rNECK\0\rHEAD\0\rNEAREST\0\0");

//const char* targetMode = XorStr("FOV\0\rDistance\0\rThreat\0\0");

const char* wepGroups[] =
{
	"Pistols",
	"Rifles",
	"SMG",
	"Shotgun",
	"Snipers"
};

const char* keyNames[] = 
{
	"",
	"Mouse 1",
	"Mouse 2",
	"Cancel",
	"Middle Mouse",
	"Mouse 4",
	"Mouse 5",
	"",
	"Backspace",
	"Tab",
	"",
	"",
	"Clear",
	"Enter",
	"",
	"",
	"Shift",
	"Control",
	"Alt",
	"Pause",
	"Caps",
	"",
	"",
	"",
	"",
	"",
	"",
	"Escape",
	"",
	"",
	"",
	"",
	"Space",
	"Page Up",
	"Page Down",
	"End",
	"Home",
	"Left",
	"Up",
	"Right",
	"Down",
	"",
	"",
	"",
	"Print",
	"Insert",
	"Delete",
	"",
	"0",
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"H",
	"I",
	"J",
	"K",
	"L",
	"M",
	"N",
	"O",
	"P",
	"Q",
	"R",
	"S",
	"T",
	"U",
	"V",
	"W",
	"X",
	"Y",
	"Z",
	"",
	"",
	"",
	"",
	"",
	"Numpad 0",
	"Numpad 1",
	"Numpad 2",
	"Numpad 3",
	"Numpad 4",
	"Numpad 5",
	"Numpad 6",
	"Numpad 7",
	"Numpad 8",
	"Numpad 9",
	"Multiply",
	"Add",
	"",
	"Subtract",
	"Decimal",
	"Divide",
	"F1",
	"F2",
	"F3",
	"F4",
	"F5",
	"F6",
	"F7",
	"F8",
	"F9",
	"F10",
	"F11",
	"F12",

}; 
//SE_PROTECT_END;