#pragma once

class IVPanel
{
public:
	const char* GetName(int iPanel);
};