#pragma once

class IClientModeShared
{
public:

}; 