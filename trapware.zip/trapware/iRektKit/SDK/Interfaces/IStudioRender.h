#pragma once

class IStudioRender;